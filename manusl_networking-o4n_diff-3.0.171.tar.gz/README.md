# Ansible Collection - octupus.o4n_diff

## Octupus Collection

Collection o4n_diff helps developers to take diff with 2 text files.  
By Ed Scrimaglia

## Required

Ansible >= 2.10

## Modules

o4n_diff
The collection allow to find and displays the differences between two files in the context of configurartions compliance. The module works either for whole configurations (config) or a block of sentences (context).  
